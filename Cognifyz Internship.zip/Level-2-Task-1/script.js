// ================================
// Welcome Message
// ================================

window.addEventListener("load", () => {

    alert("Welcome to Cognifyz Level 2 Task 1!");

});

// ================================
// Smooth Button Animation
// ================================

const buttons = document.querySelectorAll(".btn");

buttons.forEach(btn => {

    btn.addEventListener("mouseenter", () => {

        btn.style.transform = "scale(1.05)";

    });

    btn.addEventListener("mouseleave", () => {

        btn.style.transform = "scale(1)";

    });

});

// ================================
// Card Animation on Scroll
// ================================

const cards = document.querySelectorAll(".service-card");

const observer = new IntersectionObserver(entries => {

    entries.forEach(entry => {

        if(entry.isIntersecting){

            entry.target.style.opacity = "1";
            entry.target.style.transform = "translateY(0)";

        }

    });

});

cards.forEach(card => {

    card.style.opacity = "0";
    card.style.transform = "translateY(50px)";
    card.style.transition = "0.8s";

    observer.observe(card);

});

// ================================
// Contact Form Validation
// ================================

const form = document.querySelector("form");

form.addEventListener("submit",function(e){

    e.preventDefault();

    const inputs = document.querySelectorAll(".form-control");

    let valid = true;

    inputs.forEach(input=>{

        if(input.value.trim()==""){

            valid = false;

            input.style.border = "2px solid red";

        }else{

            input.style.border = "2px solid green";

        }

    });

    if(valid){

        alert("Message Sent Successfully!");

        form.reset();

    }

});

// ================================
// Navbar Active Link
// ================================

const navLinks = document.querySelectorAll(".nav-link");

navLinks.forEach(link=>{

    link.addEventListener("click",()=>{

        navLinks.forEach(l=>l.classList.remove("active"));

        link.classList.add("active");

    });

});

// ================================
// Footer Year
// ================================

const footer = document.querySelector("footer p");

footer.innerHTML =
"© " + new Date().getFullYear() +
" Nitin Lahane | Cognifyz Level 2 Task 1";